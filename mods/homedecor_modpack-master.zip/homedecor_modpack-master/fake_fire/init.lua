--[[

The 'Fake-Fire' mod was originally created by Semmett9.

URL to the 'Fake-Fire' thread on Minetest.net:
http://forum.minetest.net/viewtopic.php?id=6145

I've customized it a bit. Please see the changelog.txt file for more details.

~ LazyJ, 2014_03_15

--]]

dofile(minetest.get_modpath("fake_fire").."/modfiles/nodes.lua")
dofile(minetest.get_modpath("fake_fire").."/modfiles/crafts.lua")
dofile(minetest.get_modpath("fake_fire").."/modfiles/abms.lua")



--[[

	The lines below, at the end, are from the original author, Semmett9.

	Thanks for a nice mod, Semmett9. ;)

	~ LazyJ, 2014_03_14

--]]



-- Thanks-

-- Many thanks for addi for his help in coding. --

-- Many thanks for the players on the King Arthur's land server for giving --
-- me support, ideas and allowing me to add the mod to the server itself. --
